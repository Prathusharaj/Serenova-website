SERENOVA SIMPLE WEBSITE

Files included:
- index.html
- styles.css
- logo.png        (your supplied Serenova logo)
- nature.jpg      (your supplied mountain/lake image)

Open index.html in a browser to preview the website.
The two supplied images are already connected to the page.
